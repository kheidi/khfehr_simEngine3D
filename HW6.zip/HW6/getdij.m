function dij = getdij(r_i,r_j,s_i_P,s_j_P)
% GETDIJ
%
% Author: K. Heidi Fehr
% Email: kfehr@wisc.edu
% October 2020; Last revision: 8-Oct-2020
%
% TO-DO:
    dij = r_j+s_j_P-r_i-s_i_P;
end