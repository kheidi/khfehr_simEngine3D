initial = [.7;.1;.7;.1];
[phiResultsD,locationD] = simEngine3D_A6P2(0,initial);